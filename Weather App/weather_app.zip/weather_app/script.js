const apiKey = '4ff21f49ca2705efc645841f72593668'; //OpenWeatherMap API key
const weatherButton = document.getElementById('get-weather');
const weatherResult = document.getElementById('weather-result');

weatherButton.addEventListener('click', async () => {
    const city = document.getElementById('city-input').value.trim();

    if (!city) {
        weatherResult.innerHTML = `<p>Please enter a city name.</p>`;
        return;
    }

    try {
        const response = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`   // directory for json api format in  platform 
        );

        if (!response.ok) {
            throw new Error('City not found');
        }

        const data = await response.json();
        const { name } = data;
        const { temp } = data.main;
        const { description, icon } = data.weather[0];

        weatherResult.innerHTML = `
      <h2>Weather in ${name}</h2>
      <p>Temperature: ${temp}°C</p>
      <p>${description}</p>
      <img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="${description}">
    `;
    } catch (error) {
        weatherResult.innerHTML = `<p>Error: ${error.message}</p>`;
    }
});
