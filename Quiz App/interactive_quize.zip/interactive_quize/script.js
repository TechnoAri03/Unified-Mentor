// Question bank
const questions = [
    {
        question: "What is the capital of France?",
        choices: ["Paris", "Berlin", "Rome", "Madrid"],
        answer: "Paris"
    },
    {
        question: "Which planet is known as the Red Planet?",
        choices: ["Earth", "Mars", "Jupiter", "Saturn"],
        answer: "Mars"
    },
    {
        question: "Who wrote 'Hamlet'?",
        choices: ["Charles Dickens", "William Shakespeare", "Leo Tolstoy", "Mark Twain"],
        answer: "William Shakespeare"
    },
    {
        question: "What is the largest ocean on Earth?",
        choices: ["Atlantic", "Indian", "Arctic", "Pacific"],
        answer: "Pacific"
    },
    {
        question: "What gas do plants absorb from the atmosphere?",
        choices: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"],
        answer: "Carbon Dioxide"
    }
];

const form = document.getElementById('quiz-form');

// Dynamically create quiz questions
function loadQuiz() {
    questions.forEach((q, index) => {
        const questionBlock = document.createElement('div');
        questionBlock.className = 'question';

        const qTitle = document.createElement('h3');
        qTitle.textContent = `${index + 1}. ${q.question}`;
        questionBlock.appendChild(qTitle);

        const options = document.createElement('div');
        options.className = 'options';

        q.choices.forEach(choice => {
            const label = document.createElement('label');
            const radio = document.createElement('input');
            radio.type = 'radio';
            radio.name = `question${index}`;
            radio.value = choice;

            label.appendChild(radio);
            label.append(choice);
            options.appendChild(label);
        });

        questionBlock.appendChild(options);
        form.appendChild(questionBlock);
    });
}

// Score calculation
function calculateScore() {
    let score = 0;
    questions.forEach((q, index) => {
        const selected = document.querySelector(`input[name="question${index}"]:checked`);
        if (selected && selected.value === q.answer) {
            score++;
        }
    });

    const result = document.getElementById('result');
    result.textContent = `You scored ${score} out of ${questions.length}`;
}

document.getElementById('submit-btn').addEventListener('click', function (e) {
    e.preventDefault();
    calculateScore();
});

loadQuiz();
