import React, { useEffect, useState } from 'react';
import { db } from '../../firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';

export default function Filter() {
    const [category, setCategory] = useState("");
    const [maxPrice, setMaxPrice] = useState("");
    const [products, setProducts] = useState([]);

    const applyFilter = async () => {
        let q = collection(db, "products");
        if (category && maxPrice) {
            q = query(q, where("category", "==", category), where("price", "<=", parseFloat(maxPrice)));
        } else if (category) {
            q = query(q, where("category", "==", category));
        } else if (maxPrice) {
            q = query(q, where("price", "<=", parseFloat(maxPrice)));
        }
        const querySnapshot = await getDocs(q);
        const filteredProducts = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setProducts(filteredProducts);
    };
    return (
        <div className="p-4">
            <h2 className="text-xl font-bold">Filter Products</h2>
            <input placeholder="Category" className="border m-2 p-1" onChange={e => setCategory(e.target.value)} />
            <input placeholder="Max Price" className="border m-2 p-1" type="number" onChange={e => setMaxPrice(e.target.value)} />
            <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={applyFilter}>Apply</button>

            <ul className="mt-4">
                {products.map(product => (
                    <li key={product.id} className="border p-2 my-1">
                        <strong>{product.name}</strong> - ₹{product.price}
                    </li>
                ))}
            </ul>
        </div>
    );
}
