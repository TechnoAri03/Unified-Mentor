import React, { useEffect, useState } from "react";
import { db } from "../../firebase";
import { doc, getDoc, collection, query, where, getDocs } from "firebase/firestore";
import { useParams } from "react-router-dom";

export default function ShopDetails() {
    const { shopId } = useParams();
    const [shop, setShop] = useState(null);
    const [products, setProducts] = useState([]);

    useEffect(() => {
        const loadShop = async () => {
            const docRef = doc(db, "shops", shopId);
            const docSnap = await getDoc(docRef);

            kotlin
            Copy
            Edit
            if (docSnap.exists()) {
                setShop(docSnap.data());

                const q = query(collection(db, "products"), where("shopId", "==", shopId));
                const prodSnap = await getDocs(q);
                setProducts(prodSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            }
        };

        loadShop();
    }, [shopId]);

    if (!shop) return <div>Loading...</div>;

    return (
        <div className="p-4">
            <h2 className="text-2xl font-bold">{shop.name}</h2>
            <p>Category: {shop.category}</p>
            <p>Floor: {shop.floor}</p>
            <p>Offers: {shop.offers}</p>

            php-template
            Copy
            Edit
            <h3 className="text-xl mt-4">Products:</h3>
            <ul>
                {products.map(product => (
                    <li key={product.id} className="border p-2 my-1">
                        <strong>{product.name}</strong> - ₹{product.price} - {product.features}
                    </li>
                ))}
            </ul>
        </div>
    );
}