import React, { useEffect, useState } from "react";
import { db } from "../../firebase";
import { collection, query, where, getDocs } from "firebase/firestore";

export default function FloorView() {
    const [floor, setFloor] = useState("");
    const [shops, setShops] = useState([]);

    const fetchShops = async () => {
        const q = query(collection(db, "shops"), where("floor", "==", floor));
        const snap = await getDocs(q);
        const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setShops(data);
    };

    return (
        <div className="p-4">
            <h2 className="text-xl font-bold">Floor-wise Shops</h2>
            <input placeholder="Enter Floor Number" className="border m-2 p-1" onChange={e => setFloor(e.target.value)} />
            <button className="bg-green-600 text-white px-4 py-2 rounded" onClick={fetchShops}>Show Shops</button>

            <ul className="mt-4">
                {shops.map(shop => (
                    <li key={shop.id} className="border p-2 my-1">
                        <strong>{shop.name}</strong> - Category: {shop.category}
                    </li>
                ))}
            </ul>
        </div>
    );
}