import React, { useEffect, useState } from 'react';
import { db } from '../../firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';

export default function CategoryView() {
    const [category, setCategory] = useState('');
    const [shops, setShops] = useState([]);

    const fetchShops = async () => {
        const q = query(collection(db, 'shops'), where('category', '==', category));
        const snap = await getDocs(q);
        setShops(snap.docs.map(doc => doc.data()));
    };

    return (
        <div>
            <input placeholder="Enter Category" onChange={e => setCategory(e.target.value)} />
            <button onClick={fetchShops}>Search</button>
            <ul>
                {shops.map((shop, idx) => (
                    <li key={idx}>{shop.name} - Offers: {shop.offers}</li>
                ))}
            </ul>
        </div>
    );
}