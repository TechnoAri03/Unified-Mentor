import React, { useState } from 'react';
import { db } from '../../firebase';
import { collection, addDoc } from 'firebase/firestore';

export default function ManageCategoryFloor() {
    const [category, setCategory] = useState('');
    const [floor, setFloor] = useState('');

    const addCategory = async () => {
        await addDoc(collection(db, 'categories'), { name: category });
        alert('Category added');
    };

    const addFloor = async () => {
        await addDoc(collection(db, 'floors'), { level: floor });
        alert('Floor added');
    };

    return (
        <div>
            <input placeholder="New Category" onChange={e => setCategory(e.target.value)} />
            <button onClick={addCategory}>Add Category</button>
            <br />
            <input placeholder="New Floor" onChange={e => setFloor(e.target.value)} />
            <button onClick={addFloor}>Add Floor</button>
        </div>
    );
}