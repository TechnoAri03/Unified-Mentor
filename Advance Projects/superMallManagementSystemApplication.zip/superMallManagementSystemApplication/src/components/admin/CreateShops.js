import React, { useState } from 'react';
import { db } from '../../firebase';
import { collection, addDoc } from 'firebase/firestore';
import { logAction } from '../../utils/logger';

export default function CreateShop() {
    const [shop, setShop] = useState({ name: '', category: '', floor: '', offers: '' });

    const createShop = async () => {
        await addDoc(collection(db, 'shops'), shop);
        logAction("Created Shop", shop);
        alert('Shop created');
    };

    return (
        <div>
            <h2>Create Shop</h2>
            <input placeholder="Shop Name" onChange={e => setShop({ ...shop, name: e.target.value })} />
            <input placeholder="Category" onChange={e => setShop({ ...shop, category: e.target.value })} />
            <input placeholder="Floor" onChange={e => setShop({ ...shop, floor: e.target.value })} />
            <input placeholder="Offers" onChange={e => setShop({ ...shop, offers: e.target.value })} />
            <button onClick={createShop}>Create</button>
        </div>
    );
}