import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AdminLogin from './components/admin/AdminLogin';
import CreateShop from './components/admin/CreateShop';
import CategoryView from './components/user/CategoryView';

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<AdminLogin />} />
                <Route path="/admin/create-shop" element={<CreateShop />} />
                <Route path="/category" element={<CategoryView />} />
            </Routes>
        </BrowserRouter>
    );
}

