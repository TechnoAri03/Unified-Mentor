import React, { useState } from "react";
import { auth, db } from "../firebase";
import { collection, addDoc } from "firebase/firestore";

export default function TeacherDashboard() {
    const [date, setDate] = useState("");

    const schedule = async () => {
        await addDoc(collection(db, "appointments"), {
            teacherId: auth.currentUser.uid,
            time: date,
            status: "available"
        });
    };

    return (
        <div>
            <h1>Schedule Appointment</h1>
            <input type="datetime-local" onChange={e => setDate(e.target.value)} />
            <button onClick={schedule}>Add</button>
        </div>
    );
}