import React, { useEffect, useState } from "react";
import { db, auth } from "../firebase";
import { collection, query, where, getDocs, updateDoc, doc } from "firebase/firestore";

export default function StudentDashboard() {
    const [appointments, setAppointments] = useState([]);

    useEffect(() => {
        const fetch = async () => {
            const q = query(collection(db, "appointments"), where("status", "==", "available"));
            const snap = await getDocs(q);
            setAppointments(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        };
        fetch();
    }, []);

    const book = async (id) => {
        await updateDoc(doc(db, "appointments", id), {
            studentId: auth.currentUser.uid,
            status: "pending"
        });
    };

    return (
        <div>
            <h1>Available Appointments</h1>
            {appointments.map(app => (
                <div key={app.id}>
                    {app.time} <button onClick={() => book(app.id)}>Book</button>
                </div>
            ))}
        </div>
    );
}