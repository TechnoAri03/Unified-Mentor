import React, { useEffect, useState } from "react";
import { db } from "../firebase";
import { collection, getDocs, updateDoc, doc } from "firebase/firestore";

export default function AdminDashboard() {
    const [students, setStudents] = useState([]);

    useEffect(() => {
        const fetchStudents = async () => {
            const snapshot = await getDocs(collection(db, "users"));
            const filtered = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
                .filter(u => u.role === "student" && !u.approved);
            setStudents(filtered);
        };
        fetchStudents();
    }, []);

    const approveStudent = async (id) => {
        await updateDoc(doc(db, "users", id), { approved: true });
    };

    return (
        <div>
            <h1>Pending Student Approvals</h1>
            {students.map(student => (
                <div key={student.id}>
                    {student.email} <button onClick={() => approveStudent(student.id)}>Approve</button>
                </div>
            ))}
        </div>
    );
}