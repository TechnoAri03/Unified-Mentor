const audio = document.getElementById('audio');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const progress = document.getElementById('progress');
const volumeSlider = document.getElementById('volume');
const title = document.getElementById('title');
const artist = document.getElementById('artist');
const playlist = document.getElementById('playlist');

// Song list
const songs = [
    { title: "Song One", artist: "Artist A", file: "songs/song1.mp3" },
    { title: "Song Two", artist: "Artist B", file: "songs/song2.mp3" },
    { title: "Song Three", artist: "Artist C", file: "songs/song3.mp3" },
];

let songIndex = 0;

// Load song
function loadSong(song) {
    title.textContent = song.title;
    artist.textContent = song.artist;
    audio.src = song.file;
}

// Populate playlist
songs.forEach((song, index) => {
    const li = document.createElement('li');
    li.textContent = `${song.title} - ${song.artist}`;
    li.onclick = () => {
        songIndex = index;
        loadSong(songs[songIndex]);
        playSong();
    };
    playlist.appendChild(li);
});

function playSong() {
    audio.play();
    playBtn.textContent = "⏸️";
}

function pauseSong() {
    audio.pause();
    playBtn.textContent = "▶️";
}

playBtn.onclick = () => {
    if (audio.paused) {
        playSong();
    } else {
        pauseSong();
    }
};

prevBtn.onclick = () => {
    songIndex = (songIndex - 1 + songs.length) % songs.length;
    loadSong(songs[songIndex]);
    playSong();
};

nextBtn.onclick = () => {
    songIndex = (songIndex + 1) % songs.length;
    loadSong(songs[songIndex]);
    playSong();
};

audio.ontimeupdate = () => {
    const progressPercent = (audio.currentTime / audio.duration) * 100;
    progress.value = progressPercent || 0;
};

progress.oninput = () => {
    audio.currentTime = (progress.value * audio.duration) / 100;
};

volumeSlider.oninput = () => {
    audio.volume = volumeSlider.value;
};

// Init
loadSong(songs[songIndex]);
audio.volume = 0.5;
volumeSlider.value = 0.5;
