const startBtn = document.getElementById('start-btn');
const datetimePicker = document.getElementById('datetime-picker');
const daysEl = document.getElementById('days');
const hoursEl = document.getElementById('hours');
const minutesEl = document.getElementById('minutes');
const secondsEl = document.getElementById('seconds');
const messageEl = document.getElementById('message');

let countdownInterval;
// function of button and error handling
startBtn.addEventListener('click', () => {
    const targetDate = new Date(datetimePicker.value);
    if (isNaN(targetDate.getTime())) {
        alert("Please select a valid date and time.");
        return;
    }

    clearInterval(countdownInterval);

    // input for set interval
    countdownInterval = setInterval(() => {
        const now = new Date();
        const timeDiff = targetDate - now;

        if (timeDiff <= 0) {
            clearInterval(countdownInterval);
            daysEl.textContent = hoursEl.textContent = minutesEl.textContent = secondsEl.textContent = '00';
            messageEl.textContent = "Time's up!";
            return;
        }

        const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeDiff / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((timeDiff / (1000 * 60)) % 60);
        const seconds = Math.floor((timeDiff / 1000) % 60);

        daysEl.textContent = String(days).padStart(2, '0');
        hoursEl.textContent = String(hours).padStart(2, '0');
        minutesEl.textContent = String(minutes).padStart(2, '0');
        secondsEl.textContent = String(seconds).padStart(2, '0');

        messageEl.textContent = '';
    }, 1000);
});
